# Agent guide

This project is meant to be kept by a coding agent. Not tolerated by one, but
built for it: no dependencies to resolve, no build step to wait for, a test
suite that finishes in under twenty seconds, and every rule that matters written
down here instead of living in someone's head.

Read this before you touch anything. It is short on purpose.

Before adding anything, read [FEATURES.md](FEATURES.md): the map of what the
journal already does and the names traders use for it. A request that uses
the words of a trader, a trading system, a checklist, risk management, a
watchlist, nearly always names a thing that is already here under a name of
its own, and the answer is the tab, not a new one. A new tab has been built
twice for a thing that existed; do not make it three.

If you are working through Claude Code, `CLAUDE.md` points here. Other tools
read this file directly.

---

## 1. Whose data this is

The owner's trading history sits behind this code: every position, its size and
the thinking behind it. Treat it the way you would treat someone's medical
records.

- **Never send records anywhere.** Not to a cloud, not to a paste service, not
  into a chat, not into an issue. Summary figures answer nearly every question;
  quote a trade only when the owner asked about that trade.
- **Never commit records.** `python3 tools/check_public.py` refuses a push that
  would leak them (the tree, `.trash`, `.drafts` and the commits being
  pushed), and it runs as a pre-push hook and in CI. Do not work around it. If it fires, it is right and you are wrong.
- **Never delete outright.** Removing a trade or a card means moving it to
  `.trash`. If you delete something yourself, do the same.
- **Never rewrite history to fix a number.** A balance that disagrees with the
  broker is recorded as an adjustment in `journal/adjustments/` with a comment,
  not by editing old trades.
- **Screenshots are records too.** They are chart captures the owner took; the
  same rules apply.

## 2. Running it

```bash
python3 -m unittest discover -s tests    # the whole suite, under twenty seconds
python3 tools/check_public.py            # nothing private in the tree
python3 tools/check_journal.py [root]    # does every record read
python3 -m plainbook.server              # http://localhost:8778
python3 -m plainbook                     # the same
```

The `plainbook` command of a pipx install and the downloaded file of a release
run the same server through `server.app` and open the browser on it;
`python3 -m plainbook.server` and the autostart units open nothing; the
macOS and Windows entries of `desktop/` start it with `--background`, which opens nothing whatever the entry,
and on Windows hands the journal to a copy with no window (`server.detach`).
`PLAINBOOK_OPEN=0` or `1` overrides either way. From source the records live in
the project folder; from the file or the package, in `~/Plainbook`
(`server.default_root`).

After changing the code, restart the server. On Linux with the unit installed:

```bash
systemctl --user restart plainbook
journalctl --user -u plainbook -n 50     # the traceback when a page 500s
```

To try something without touching the owner's records, point the journal at a
scratch folder:

```bash
PLAINBOOK_ROOT=/tmp/pb-test PLAINBOOK_PORT=8899 python3 -m plainbook.server
```

## 3. The map

| file | owns |
|---|---|
| `plainbook/model.py` | the records: `Trade`, `Account`, `Adjustment`, `Card`, `Week`, `Plan`, `Playbook`, `Note`; the vocabularies a journal starts with; the checks |
| `plainbook/mdfile.py` | the markdown header format, and only that |
| `plainbook/store.py` | files ↔ objects, the folder layout, ids, the trash, the owner's lists of pairs and words |
| `plainbook/balances.py` | balances and R, computed by replaying history |
| `plainbook/stats.py` | summaries, the equity curve, the R distribution |
| `plainbook/reports.py` | monthly and quarterly reports: `compose` reads the figures off the journal on every look, `build` writes them into the file that is the archive and holds the conclusions |
| `plainbook/html.py` | the palette, the CSS, the page shell, the SVG charts |
| `plainbook/flags.py` | the round flag icons of a trading symbol, and what a symbol is taken apart into |
| `plainbook/share.py` | the document a record leaves in: one file, its pictures inside it, no money in it |
| `plainbook/server.py` | routes, pages, forms: everything HTTP; the edition gating goes only through `lite()`, `LITE_HIDDEN_TABS`, `LITE_HIDDEN_ROUTES` and `LITE_TRASH_KINDS` |
| `plainbook/__main__.py` | `python3 -m plainbook`: the same server |
| `tools/check_public.py` | the guard that keeps records out of the repository |
| `tools/check_journal.py` | loads every record the way the server does and names the ones that do not read |
| `tools/demo_journal.py` | an invented journal for screenshots and for looking at a change |
| `tools/attach_playbook.py` | ties the trades a playbook was already traded by to it: its styles, from its `since` date |
| `tools/import_csv.py` | old trades brought in from a CSV table (a Notion export, a spreadsheet), written as the interface writes them |
| `tools/app_entry.py` | the entry of the downloaded file: what PyInstaller packs |
| `tools/pypi_readme.py` | the README with its links made absolute on a tag, for the page of the package on pypi.org; the publish workflow runs it on its own checkout |
| `tools/browser_check.mjs` | the scripted forms driven in a headless Chromium against a demo journal |
| `tools/screenshots.py` | retakes the pictures of README.md in `docs/` on the demo journal; run it after a release; `--edition=lite` takes the Plainbook Lite ones into `docs/lite/` |
| `tests/` | the suite: `test_server.py` walks the routes on one shared journal, the others take the modules one by one; `formpost.py` reads a form of a page the way a browser sends it |
| `docs/` | the screenshots of README.md, taken on the demo journal |
| `desktop/` | the autostart of each system (the user unit for Linux, the LaunchAgent for macOS, the script that makes the startup shortcut on Windows), the window toggle and the bar widget for Omarchy; see its README |
| `.githooks/pre-push` | runs `check_public.py` before a push; turned on once with `git config core.hooksPath .githooks` |
| `.github/workflows/tests.yml` | the suite and the guard on every push, on Python 3.10 and 3.14, three systems |
| `pyproject.toml` | the package on PyPI, `plainbook-journal`: the `plainbook` command of a pipx install; nothing in it is needed to run from source |
| `.github/workflows/release.yml` | builds one file per system from a published release, attests it, attaches it |
| `.github/workflows/publish.yml` | puts the package of a published release on PyPI, by trusted publishing: no token anywhere |

The dependency direction is one way: `server → html → flags`, `server → stats,
reports, share, balances, store → model → mdfile`, with `reports` and `share`
reading `html` and `stats` sideways for the words and the figures they print,
and `balances` reading `store`. Nothing points back up. If you find yourself
importing `server` from anywhere, the design has gone wrong.

Routes live in `Handler.do_GET` and `Handler.do_POST` at the bottom of
`server.py`, and they are a flat list of `if` statements on purpose, so that the
routing table reads top to bottom and needs no framework to read. A record
that is not there answers with `_gone`, a page, never a bare phrase; a record
whose file does not read answers with the same page and the reason on top.

## 4. Invariants

Break one of these and something breaks quietly, days later, in the owner's
data. Each one is followed by what it prevents.

1. **Nothing computable is stored.** Balance and R are worked out on every load.
   The one exception is written down: a card keeps the PnL of its day, and a
   weekly card its PnL and its count of trades, prefilled from the journal and
   saved as the owner left them, because the figure a day is reviewed by is the
   owner's. *Prevents:* a stored number drifting away from the history that
   produced it.
2. **A trade's `shots/` folder is rewritten whole** from what the form sent
   (`apply_shots`). Every form that edits a trade must therefore send back
   **all** of its screenshot zones, including the ones it does not display.
   *Prevents:* screenshots vanishing off the disk when an unrelated field is
   edited. This has already happened once, to the exit shots. The zones are
   the one place where the rule of invariant 14 is turned around: a zone not
   sent is a zone emptied.
3. **A header key with no value parses into an empty list, not an empty
   string**, which is how lists are written in the format. Read header strings
   through `store._text`, and never write an empty value into a header.
   *Prevents:* `float('[]')` killing the page, and `"[]"` showing up in the
   interface.
4. **Win rate = wins / (wins + losses)**, break-evens excluded; "trades"
   counts every closed trade. The EV is Σ R over the trades whose R could be
   measured (a balance at entry above zero), break-evens included, and its
   captions print `Summary.measured`, not `trades`. `Summary.average_r` is the
   EV and goes by the name EV everywhere on the screen. All are defined in
   `stats.Summary` and repeated in the reports and in the captions.
   *Prevents:* two numbers on the same screen disagreeing about the same trades.
5. **The server binds 127.0.0.1 and has no authentication.** Keep it that way,
   and keep the `Origin` check in `_same_origin` and the `Host` check in
   `_own_host`. *Prevents:* a journal with no login ending up reachable from
   a network, and a web page reading it by pointing a name of its own at
   127.0.0.1 (DNS rebinding), which the `Host` header gives away.
6. **No dependencies.** The standard library is the whole toolbox. A package
   that looks harmless today is an install failure in five years. PyInstaller
   and setuptools are tools of the release workflow, used on GitHub's
   machines to pack the source; the source never imports them.
7. **Everything is offline.** No CDN, no web fonts, no analytics, no update
   check. Styles and scripts are inlined into the page.
8. **Ids are file names.** Anything arriving from a URL and used as a path goes
   through `store.safe_dir_name` first.
9. **The lists in `journal/vocabulary.md` are what the form offers, not what a
   trade is allowed to hold.** Styles, timeframes and execution formats are the
   owner's, so a word taken out of a list must still load, still show in the
   statistics, and still be drawn in the form of a trade that carries it
   (`server.offered`). Nothing validates a trade against these lists.
   *Prevents:* retiring a style quietly deleting it from the trades that have
   it, since a form deletes what it does not draw.
10. **A record that does not read is named, not fatal.** Every reader in
    `store.py` takes a `problems` list (`store._load`): a file that fails is
    written there as (path, reason) and skipped, `Journal.load` collects the
    list, and `server.page` shows it on every page. Without the list the error
    is raised, which is what the tests and the checking tool want.
    *Prevents:* one mistyped date leaving every page blank with the reason only
    in the log, which is what happened before 1.4.3. The owner's own files,
    `settings.md`, `vocabulary.md` and `pairs.md`, read as the defaults when
    they do not parse, and a save over one of them is refused (`store._writable`):
    a rewrite from the defaults would take every word the mistake hid.
11. **What leaves the journal is built in `share.py`, and it names every
    field it shows.** The module holds no money at all: it never imports
    `html.money` and never reads `pnl`, `risk_money` or a balance, and a
    field reaches a document only because a function there asks for it.
    Never turn that around into a page of the journal with the money
    stripped out. *Prevents:* a field added to a trade walking out of the
    owner's journal a year later because nobody remembered a document
    existed.

12. **A period is measured by the exit** in a report, in the period tile of
    the front page and in the cards; the list of trades, its filters and the
    totals of its groups go by the entry. The one figure of a report that is
    not money and not measured by the exit is `days_traded`, the days a card
    is written against: it counts entries, because a card is written on the
    day the owner traded, and a position closing on its own asks for none. *Prevents:* a report whose result in
    money and balance change disagree by the trades that ran across its edge,
    which is what they did before 1.4.6.

    The one list read by the exit is **Trades of this period** on the
    Statistics tab (`period_trades_card`), because it is the very set the
    figures above it were worked out on. It is flat, so it has no group
    totals to disagree with anything, it is ordered by the exit, and it
    prints both dates. Do not helpfully put it back on the entry: the cut
    used to be carried to the journal as the months it covered, and that
    list was a different set of trades under the same title.

13. **A trade's `deviations` is None or a list, and the two mean different
    things.** None: the trade was tied to its playbook without a checklist
    (the key is absent from the file). A list, empty included: the rules
    were ticked, and these are the ones not met (the key stands, empty for
    a clean trade). `exit_deviations` works the same for the management
    rules, ticked at the close. Only ticked trades hold a playbook's version
    and take part in the cost of a rule. A form that does not draw the lists
    leaves both as they stand (invariant 14). *Prevents:* a trade attached later counting
    as clean, and a screenshot fix turning "not ticked" into "every rule
    broken".

14. **A key the form did not send is left as it is; a key sent blank clears
    it.** `apply_fields`, `apply_playbook` and `apply_management` ask whether
    `plan`, `playbook` and `ticked_exit` are in the form before they read
    them, and the body is parsed with `keep_blank_values`, so the `-` of a
    select still unties a trade. A group of checkboxes sends nothing when
    none is ticked, so it cannot be told from a group that was not drawn:
    such a group needs a hidden marker that the form always sends with it,
    which is what `ticked` (the checklist) and `ticked_exit` (the management
    rules) are. The screenshot zones are the exception: a zone not sent is
    emptied, so every form of a trade sends them all (invariant 2).
    `execution` has no marker and is safe only while every form
    of a trade draws it. A form of either edition, the full journal or Lite,
    may save a record written by the other, so a form reads only the fields
    it draws and leaves the rest of the record byte for byte as it was
    (`tests/test_forms.py` posts the form as the page draws it, through
    `tests/formpost.py`). *Prevents:* an edit in Lite wiping the plan, the
    playbook, the setup and the reasons of a trade, and a close in Lite
    writing "every management rule not held".

15. **The edition hides, it never deletes or migrates.** The journal is the
    full Plainbook unless `journal/settings.md` says `edition: lite`; there is
    one record format for both, and the key is removed, never written empty,
    when the full journal is chosen again (invariant 3). Lite takes tabs,
    fields, rows and buttons off the screen, and every file behind them stays
    as it is, so a record written in one edition reads and saves in the
    other. All the gating goes through `lite()`, `LITE_HIDDEN_TABS`,
    `LITE_HIDDEN_ROUTES` and `LITE_TRASH_KINDS` in `server.py`, and "lite" is
    compared nowhere else. A hidden address answers a short page, but a POST to one is not
    refused: the save goes through and then leads to that page, because
    refusing would lose what the owner pasted. A new feature is either shown
    in Lite or added to the lists. *Prevents:* Lite turning into a second
    format that the full journal cannot read, and a screen that no longer
    draws a field wiping it from the file (invariant 14).

## 5. Recipes

**Add a field to a trade.** `model.py`: the dataclass field and an entry in
`TRADE_KEYS` (the tuple is `(attribute, header key)`); a rule in `check()` if it
can be wrong. `store.py`: write it in `trade_to_text`, read it in
`text_to_trade`. `server.py`: the input in `trade_form`, the read in
`apply_fields`, a row in `trade_page`. Then a round-trip test in
`tests/test_store.py`. Old files without the key must still load, which is what
`extra` and the `.get` defaults are for.

**Touch the screenshots of a record.** A trade and a plan both keep pictures in
a `shots` folder inside their own directory, and both go through the same three
functions: `zone_sources` reads a zone of the form, `apply_shots` rewrites the
folder whole, `shot_in_zone` draws a thumbnail. They take the record's folder
and the address its pictures are served from, never a trade, so a third kind of
record with screenshots needs no new code here.

A form that shows **one** zone of a record must not call `apply_shots`: the
rewrite would take every picture the form does not draw (invariant 2). There
are two such forms, the update on the plan page and the review on the
playbook page, and both use `add_shots`, which copies the new pictures in
under the first free numbers and touches nothing else. A picture that lives inside a text is kept there as `![](shots/name.png)`;
`place_shots` puts the new names back where the old ones stood after a rewrite,
matching each link by the picture it names and never by its place, so a
picture removed from the middle takes its own link with it; `with_shots` draws
them on the page.

**Add a page.** A function returning `H.page(title, body, tab, header_right)`,
one `if` in `do_GET`, and a tab in the `links` list in `html.page` if it belongs
in the navigation. Anything user-supplied goes through `esc()`.

**Answer a form.** A form that writes something ends in `self._go(where, "What
happened")`, and the word rides in `?said=` to the page the redirect lands on:
`do_GET` takes it out of the query before any page sees it, `server.page` draws
it in the middle of the screen, and it fades out on its own. Keep it short and
in the past tense, because it is gone in a second.

**Change the look.** Everything visual is in `html.py`: the palette constants at
the top, then one `CSS` string. The one exception is `flags.py`, which draws the
coins of a trading symbol; `html.pair()` is what a page calls, and anything that
prints a pair should call it instead of `esc()`. Class names are English and
short (`card`, `tile`, `dropzone`, `shot`, `num`). The theme is deliberately
flat: no gradients; drop shadows only on what floats over the page (the filter
popover, the pair list, the toast); motion only in the toast that answers a
form, the short (.12s) colour change on hover and focus, and the fade of an
opened popover or fold, and all of it is off under prefers-reduced-motion.
One named exception: the two edition switches, `.toggle` on Accounts and the
header `.lite-switch`, whose knobs slide in .18s, because a switch that does
not move does not read as one; both are off under prefers-reduced-motion like
the rest, and the forms behind them work with no script.
Depth is drawn with flat colour only: a strip of tiles is three
surfaces and a lit top edge a pixel thick, and a column of the day by day
is two sides and a roof in three steps of one colour (`_block`). A figure a picture shows under the pointer rides in a
`data-tip` attribute (`H.tip`), which the page script puts in the tip box
at once; a `<title>` waits a second and a half and is not seen.

**Hide something in Plainbook Lite.** A new tab or page that belongs to the
full Plainbook only: add its tab to `LITE_HIDDEN_TABS` and every address
prefix it answers, pages and pictures and shares, to `LITE_HIDDEN_ROUTES`,
both in `server.py`. A new record kind with a trash entry that Lite keeps goes
into `LITE_TRASH_KINDS`, or its trash entries stay hidden and its Restore is
refused in Lite. A card, row or field inside a page that Lite keeps: draw
it only `if not lite()`, and if it is a field of a form, read it only when the
form sent it (invariant 14), so a Lite save leaves it as it was. Nothing is
deleted or converted, and a test in `tests/test_lite.py` saves a record
through Lite and compares the files before and after.

**Add a statistic.** `stats.py` computes, `server.py` displays. Keep the
computation free of HTML and the display free of arithmetic; that split is why
the numbers can be tested at all.

**Change the record format.** Write a migration script in `tools/` and run it on
a *copy* of the journal first. Then compare every computed figure before and
after: trade count, balances per account, Σ R, Σ PnL, screenshot counts, the
length of every text field. They must match exactly, or the migration is wrong.
Only then touch the real journal, and say so in `CHANGELOG.md`. Make the script
idempotent: running it twice must be a no-op, because it will be run twice.

## 6. Verifying a change

In this order, every time:

1. `python3 -m unittest discover -s tests`, all green.
2. `python3 tools/check_public.py`, clean.
3. **Look at the page.** About half of this code is markup and one form script,
   and the tests go around the browser entirely. A headless screenshot is enough:
   `chromium --headless --screenshot=/tmp/page.png --window-size=1400,1000 http://localhost:8778/`
4. If you touched the paste-a-screenshot path, drive it in a real browser. It is
   the one place where browser script does the work, and it is the one place
   that has broken twice. The playbook forms are scripted too (the checklist,
   the rule rows, the limits); `node tools/browser_check.mjs` drives them in a
   headless Chromium against a demo journal, see the top of that file.
5. Run the suite on the oldest Python the README promises when you can:
   `mise install python@3.10` gives one, then
   `~/.local/share/mise/installs/python/3.10.*/bin/python3 -m unittest discover -s tests`.
   The system Python is newer than most users', and 3.12 accepts f-strings
   that 3.10 refuses.
6. Restart the server and load the page you changed.

## 7. Conventions

- **No long dashes.** Not in the documents, not in the comments, not in the
  interface. A comma, a colon, a semicolon or a full stop carries the same
  clause, and an empty value in the interface is a plain hyphen.
  `check_public.py` fires on the character, so the rule cannot quietly lapse.
- **Commit messages say why**, not what, because the diff already says what. A
  subject line, a blank line, then the reasoning. **In English**: a commit
  message is published text, sitting next to every file on the repository page.
- **`CHANGELOG.md` gets a line** for anything a user would notice, phrased as
  what changed for them. When a version is released, its heading goes in here
  and `__version__` in `plainbook/__init__.py` is raised to the same number:
  that is the figure the front page shows, and the one on the pictures of the
  README, which `tools/screenshots.py` retakes. Publishing the release puts
  that version on PyPI within minutes, and PyPI never takes a version twice:
  a fix after the release is the next version, not the same one again.
- **`GUIDE.md` gets updated** when the interface changes. It is the owner's
  manual; an out-of-date manual is worse than none.
- **Comments explain the reason**, never the mechanics. `# closewindow does not
  work from a Lua config` earns its place; `# loop over trades` does not.
- Keep functions small enough to read whole. There is no linter here and no
  formatter; match the surrounding style.

## 8. Traps that have already bitten

Real bugs from this project's history. They are here because each one cost time
and none of them was obvious from the code.

- **A token read too early.** The paste handler took the form token at the top
  of the script; the token was set by a script further down the page. Every
  upload went out as `token=undefined`. *Lesson:* read from the DOM when you
  need the value, not when the script parses.
- **A form that hid a field deleted it.** See invariant 2.
- **A window matched by title.** The desktop toggle looked for a window whose
  title starts with the app name, which is also the title of a file manager
  opened on the project folder. It raised the folder instead of the journal.
  *Lesson:* match windows by class.
- **An empty header key.** See invariant 3.
- **Drafts that never expired.** Screenshots pasted into a form that was never
  submitted stayed forever. *Lesson:* anything written outside a record needs an
  owner and an expiry.
- **A test that looked for prose found it in the CSS.** A test asserted that a
  warning phrase was absent from a page, and the phrase sat in a stylesheet
  comment that every page carries. *Lesson:* assert on markup (`class="notice"`),
  not on words.
- **Two names for one thing.** A local variable named `page` shadowed the
  `page()` function in the same routine, and every route that had both died
  with an UnboundLocalError. *Lesson:* a wrapper takes the name of what it
  wraps only when nothing else in the file has it.
- **An f-string that only newer Pythons read.** Three f-strings held a
  backslash inside their expression part, a quoted HTML snippet after `or`,
  and the server did not start on Python 3.10 or 3.11 for two releases: the
  system Python was 3.14 and CI had never run. *Lesson:* a string with a
  quote in it goes into a variable first; and step 5 above exists.
- **A handler named like a field.** A select named `limit_kind` called
  `limit_kind(this)` on change, and nothing happened: inside a form an inline
  handler looks names up in the form's fields before the page's functions,
  so the call went to the select itself. *Lesson:* a function called from an
  inline handler must not share a name with any field of that form.
- **A test that trusted the order of a folder.** Two tests took the first
  record of their kind in the trash. The server tests share one journal, so a
  record of an earlier test was there too, deleted within the same second and
  carrying the same stamp, and `os.listdir` broke the tie: newest first on
  tmpfs, oldest first on btrfs. Green here, red on another computer, three runs
  out of three. *Lesson:* a test finds its own record by id, and a sort on a
  coarse key gets a second key, or the order belongs to the disk.
