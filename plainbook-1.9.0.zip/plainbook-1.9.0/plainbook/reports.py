#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Monthly and quarterly reports.

A report is composed from the journal every time it is looked at: the figures
on the page are the journal as it is now. Building a report writes the same
figures into an ordinary markdown file in journal/reports, which is the archive
and the place the owner's "Conclusions" live; that section is NEVER overwritten.
"""
import os
import re
from dataclasses import dataclass, field, fields
from datetime import datetime, timedelta

from . import html as H
from . import mdfile, stats, store


MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July",
               "August", "September", "October", "November", "December"]

# The slices a report is cut into, in the order they are shown. The heading is
# what the file carries and what a row of the page links by, so it stays put.
SLICES = (("By style", lambda t: [t.style]),
          ("By pair", lambda t: [t.pair]),
          ("By account", lambda t: [t.account]),
          ("By direction", lambda t: [t.direction]),
          ("By entry TF", lambda t: [t.entry_tf or "not set"]),
          ("By execution", lambda t: t.execution or ["not set"]))


def path(root, period):
    return os.path.join(root, store.JOURNAL, store.REPORTS, period + ".md")


def parse_period(period):
    """'2026-08' | '2026-Q3' -> (start, end, human readable name).

    The calendar is the one of stats.py (period_bounds), so that a month or
    a quarter is cut in one place for the reports, the Statistics tab and
    the front page alike; a report knows no week."""
    grain = stats.grain_of(period or "")
    if grain not in ("month", "quarter"):
        raise ValueError(f"cannot read the period: {period!r}")
    start, end = stats.period_bounds(period)
    name = (f"Q{(start.month - 1) // 3 + 1} {start.year}" if grain == "quarter"
            else f"{MONTH_NAMES[start.month - 1]} {start.year}")
    return start, end, name


def kind_of(period):
    return "quarter" if "Q" in (period or "") else "month"


def previous_period(period):
    """'2026-08' -> '2026-07', '2026-Q1' -> '2025-Q4'. The one to compare with."""
    start, _, _ = parse_period(period)
    return period_of(start - timedelta(days=1), kind_of(period))


def next_period(period):
    """'2026-08' -> '2026-09', '2026-Q4' -> '2027-Q1'."""
    _, end, _ = parse_period(period)
    return period_of(end, kind_of(period))


def period_of(moment, kind):
    """The month or the quarter a moment falls in, as a period id."""
    if kind == "quarter":
        return stats.quarter(moment)
    return f"{moment:%Y-%m}"


def period_months(period):
    """'2026-Q3' -> ('2026-07', '2026-09'): the months the journal filters by."""
    start, end, _ = parse_period(period)
    last = end - timedelta(days=1)
    return f"{start:%Y-%m}", f"{last:%Y-%m}"


def trades_of_period(journal, period, shelf=None):
    """The trades that closed in the period.

    A period is measured by the exit, the way a broker states a month and the
    cards count a day: a trade belongs to the month it paid or cost, not to the
    one it was entered in. Without this the result in money and the balance
    change of one report disagreed by every trade that ran across its edge.
    The list on the front page groups by the entry, so a trade that crossed a
    boundary stands in one month there and in the other here."""
    parse_period(period)                   # a bad period is refused here
    if shelf is not None:
        return list(shelf.closed.get(period, ()))
    return stats.closed_in(journal.trades, period)


def still_open(journal, period, now=None):
    """The positions open now, counted beside the figures of a period that is
    still running. Blue means open everywhere in the journal, so a finished
    period shows none: what it carried over its end has closed since, and a
    position closed long ago has no business standing in blue on an old month.
    They are not in the figures, a period is measured by its exits."""
    start, end, _ = parse_period(period)
    now = now or journal.now()
    if not start <= now < end:
        return []
    return [t for t in journal.trades if t.is_open]


# Reports built before this used to carry a stub under the heading, and the
# form loaded it as text the owner had to delete before writing anything. It is
# not written any more; this recognises it in the files that already have it.
_STUB = re.compile(r"^_\(empty.*\)_$")


def conclusions_of(body):
    """The conclusions a report file carries, from the body already read:
    nothing for a file that is not there (`body` None) or holds only the stub."""
    if body is None:
        return ""
    m = re.search(r"^## Conclusions\s*$(.*)", body, re.M | re.S)
    text = m.group(1).strip() if m else ""
    return "" if _STUB.match(text) else text


def previous_conclusions(root, period):
    file = path(root, period)
    if not os.path.exists(file):
        return ""
    _, body = read(root, period)
    return conclusions_of(body)


# --- the report -----------------------------------------------------------

@dataclass
class Report:
    """Everything a report says, as figures. The page draws it, the file
    keeps it; neither does any arithmetic of its own."""
    period: str
    kind: str
    name: str
    start: datetime
    end: datetime
    earlier: str                    # the period compared with
    earlier_name: str
    trades: list                    # closed inside the period, by the exit
    was_trades: list                # the same for the period before
    total: stats.Summary
    was: stats.Summary
    fall: float                     # deepest fall from a high, in R, <= 0
    was_fall: float
    held: list = field(default_factory=list)      # open now, for a running period only
    playbooks: list = field(default_factory=list)  # [(pid, label, Summary, Compliance, setups)]
    slices: list = field(default_factory=list)     # [(heading, [(value, Summary)])]
    balances: list = field(default_factory=list)   # [(account id, before, after)]
    best: object = None
    worst: object = None
    cards: list = field(default_factory=list)      # the daily cards of the period
    weeks: list = field(default_factory=list)      # the weekly cards that began in it
    days_traded: int = 0            # days an entry was taken, by the entry
    grades: list = field(default_factory=list)     # [(grade, days)]
    ticked: int = 0                 # trades that went through a checklist
    kept: stats.Summary = None      # the ticked ones that met every rule
    broke: stats.Summary = None     # the ticked ones that broke a rule, at the entry or the close
    rules: list = field(default_factory=list)      # [(playbook label, Rule, trades, Summary)]
    past_stop: list = field(default_factory=list)  # losses at the stop edge and worse
    past_stop_cost: float = 0.0     # what those losses cost beyond the stop itself
    breakeven: stats.Breakeven = None  # the stops moved to the entry, against the rest
    entry_broken: int = 0           # ticked trades that broke a rule at the entry
    close_broken: int = 0           # closed trades that broke a management rule
    unticked: int = 0               # tied to a playbook, never ticked
    mistakes: list = field(default_factory=list)   # the trades above, each once
    mistakes_sum: stats.Summary = None
    order: list = field(default_factory=list)      # the closed trades, by the exit


class Shelf:
    """What every period of the shelf of reports reads alike, read once.

    The shelf composes every month and quarter of the journal, and each
    compose read the cards, the weeks and the playbooks off the disk again,
    scanned every trade for its period and summed every trade at both edges:
    five years of daily cards took seconds. The figures are the same either
    way: the lists keep the order the journal has them in, and a balance is
    added up in the order balance_at adds it."""

    def __init__(self, root, journal, problems=None):
        self.journal = journal
        self.cards = store.all_cards(root, problems)
        self.weeks = store.all_weeks(root, problems)
        self.playbooks = store.all_playbooks(root, problems)
        self.closed = {}
        for t in journal.trades:
            if not t.is_open and t.closed:
                for kind in ("month", "quarter"):
                    self.closed.setdefault(period_of(t.closed, kind), []).append(t)
        # what each period of the shelf holds besides its exits, grouped once
        # so that a report does not scan every card, week and entry again; the
        # lists keep the order the folders and the journal give
        self.cards_in, self.weeks_in, self.opened_in = {}, {}, {}
        for k in self.cards:
            if k.day:
                for kind in ("month", "quarter"):
                    self.cards_in.setdefault((kind, period_of(k.day, kind)), []).append(k)
        for k in self.weeks:
            if k.week:
                monday = k.monday
                for kind in ("month", "quarter"):
                    self.weeks_in.setdefault((kind, period_of(monday, kind)), []).append(k)
        for t in journal.trades:
            if t.opened:
                for kind in ("month", "quarter"):
                    self.opened_in.setdefault((kind, period_of(t.opened, kind)),
                                              set()).add(t.opened.date())
        # the money of each account in the order balance_at adds it up, so
        # that a balance comes out the same to the last digit
        self._moved, self._closed = {}, {}
        for c in journal.adjustments:
            self._moved.setdefault(c.account, []).append((c.day, c.amount))
        for t in journal.trades:
            if not t.is_open and t.closed:
                self._closed.setdefault(t.account, []).append((t.closed, t.pnl or 0.0))
        self._balances = {}

    def balance(self, account, moment):
        """balance_at, over the account's own money and once for an edge."""
        if (account, moment) not in self._balances:
            acc = self.journal.accounts.get(account)
            b = acc.start_balance if acc else 0.0
            b += sum(x for day, x in self._moved.get(account, ()) if day < moment)
            b += sum(x for day, x in self._closed.get(account, ()) if day < moment)
            self._balances[account, moment] = b
        return self._balances[account, moment]


def compose(root, journal, period, problems=None, shelf=None):
    """The report of a period, from the journal as it stands. `shelf` is what
    the page of every report passes so that the folders are read once; a
    report alone reads them itself."""
    start, end, name = parse_period(period)
    trades = trades_of_period(journal, period, shelf)
    earlier = previous_period(period)
    was_trades = trades_of_period(journal, earlier, shelf)
    r = Report(period=period, kind=kind_of(period), name=name, start=start, end=end,
               earlier=earlier, earlier_name=parse_period(earlier)[2],
               trades=trades, was_trades=was_trades,
               total=stats.summary(journal, trades),
               was=stats.summary(journal, was_trades),
               fall=stats.drawdown_r(journal, trades),
               was_fall=stats.drawdown_r(journal, was_trades))
    r.held = still_open(journal, period)
    playbooks = shelf.playbooks if shelf else None
    r.playbooks = playbook_rows(root, journal, trades, problems, playbooks)
    r.slices = [(heading, stats.by_values(journal, trades, key))
                for heading, key in SLICES]
    balance = shelf.balance if shelf else (lambda a, moment: balance_at(journal, a, moment))
    r.balances = [(a, balance(a, start), balance(a, end))
                  for a in sorted(journal.accounts)
                  if not journal.accounts[a].archived
                  or any(t.account == a for t in trades)]
    r.best, r.worst = extremes(journal, trades)
    # a card that does not read is named through `problems` and left out,
    # the way every other page treats such a file (invariant 10); without
    # the list it raises, which is what the tests want
    cards = shelf.cards if shelf else store.all_cards(root, problems)
    weeks = shelf.weeks if shelf else store.all_weeks(root, problems)
    if shelf:
        key = (r.kind, period)
        r.cards = list(shelf.cards_in.get(key, ()))
        r.weeks = list(shelf.weeks_in.get(key, ()))
    else:
        r.cards = [k for k in cards if k.day and start <= k.day < end]
        r.weeks = [k for k in weeks if k.week and start <= k.monday < end]
    # A day counted here is a day worked, and work is an entry: the morning
    # the owner sat down, took the trades and wrote the card for. A position
    # that closed on its own a week later did not make that day a working
    # one, and counting it that way asked for a card on days nothing was
    # traded. Read off the whole journal rather than off `trades`, which
    # holds the exits of the period: a trade entered inside it and closed
    # after it is not in that list at all.
    r.days_traded = (len(shelf.opened_in.get((r.kind, period), ())) if shelf else
                     len({t.opened.date() for t in journal.trades
                          if t.opened and start <= t.opened < end}))
    grades = {}
    for k in r.cards:
        grades[k.grade or "not graded"] = grades.get(k.grade or "not graded", 0) + 1
    r.grades = sorted(grades.items())
    r.breakeven = stats.breakeven_split(journal, trades)
    d = discipline(root, journal, trades, problems, playbooks)
    for f in fields(Discipline):
        setattr(r, f.name, getattr(d, f.name))
    # the order the account felt them: by the exit, the way the tape draws them
    r.order = sorted(trades, key=lambda t: (t.closed, t.id))
    return r


def playbook_rows(root, journal, trades, problems=None, playbooks=None):
    """The trades by the playbook they were opened under, its setups beneath
    it, the ones under none last. Empty when no trade names one."""
    rows = stats.by_playbook(journal, trades)
    if not any(pid != stats.NO_PLAYBOOK for pid, _, _ in rows):
        return []
    if playbooks is None:
        playbooks = store.all_playbooks(root, problems)
    names = {b.id: b.name or b.id for b in playbooks}
    out = []
    for pid, s, c in rows:
        if pid == stats.NO_PLAYBOOK:
            out.append((pid, stats.NO_PLAYBOOK, s, None, []))
            continue
        own = [t for t in trades if t.playbook == pid]
        setups = stats.by_setup(journal, own)
        if not (len(setups) > 1 or (setups and setups[0][0] != "-")):
            setups = []
        out.append((pid, names.get(pid, pid), s, c, setups))
    return out


@dataclass
class Discipline:
    """How a set of trades went through the rules: the fields of a Report
    that the Statistics tab reads off its own selection as well."""
    ticked: int = 0
    unticked: int = 0
    kept: stats.Summary = None
    broke: stats.Summary = None
    rules: list = field(default_factory=list)      # [(playbook label, Rule, trades, Summary)]
    past_stop: list = field(default_factory=list)
    past_stop_cost: float = 0.0                   # R lost beyond the stop itself
    entry_broken: int = 0
    close_broken: int = 0
    mistakes: list = field(default_factory=list)
    mistakes_sum: stats.Summary = None


def discipline(root, journal, trades, problems=None, playbooks=None, rules=True):
    """How the trades went through their checklists, and which rules were
    broken at what cost.

    Only ticked trades say anything, at the entry or at the close: one tied to
    its playbook later and never ticked anywhere was never held against the
    rules. A rule is counted by number, so only the trades
    ticked against the current version of a playbook stand in the rule rows,
    the way the playbook's own page counts them; the shares of clean and
    broken trades take every ticked trade of the period.

    Closed trades only, the way stats.checklist counts them: a position still
    in the market has no R to put against a rule, and every figure standing
    beside this one counts what is closed. A report hands over the trades of
    its period, which are closed by construction; the Statistics tab hands
    over a selection, which is not."""
    trades = [t for t in trades if not t.is_open]
    # Lite reads no rule at all: a trade ticked in the full journal counts as
    # nothing here, so the only mistake it names is a loss past the stop
    if not rules:
        ticked, playbooks = [], []
        c = stats.Checklist(ticked=0, unticked=0, kept=stats.summary(journal, []),
                            broke=stats.summary(journal, []))
    else:
        c = stats.checklist(journal, trades)
        ticked = [t for t in trades if stats.ticked(t)]
    r = Discipline(ticked=c.ticked, unticked=c.unticked, kept=c.kept, broke=c.broke)
    rows = []
    if playbooks is None:
        playbooks = store.all_playbooks(root, problems)
    for p in playbooks:
        same = [t for t in trades
                if t.playbook == p.id and t.playbook_version == p.version]
        if not same:
            continue
        costs, _ = stats.rule_costs(journal, same, p.rules)
        rows += [(p.name or p.id, rule, n, s) for rule, n, s in costs if n]
    # the dearest first: what cost the most R stands at the top
    rows.sort(key=lambda x: (x[3].sum_r, -x[2]))
    r.rules = rows
    r.past_stop = stats.past_stop(journal, trades)
    r.past_stop_cost = stats.past_stop_cost(journal, r.past_stop)
    r.entry_broken = sum(1 for t in ticked if t.deviations)
    r.close_broken = sum(1 for t in ticked if t.exit_deviations)
    # what the journal itself calls a mistake: a rule ticked as not met, at
    # the entry or at the close, or a loss past the stop. A trade that did two
    # of these is one mistake; a trade never ticked is not one either way
    seen, mistakes = set(), []
    for t in [x for x in ticked if stats.broke(x)] + r.past_stop:
        if t.id not in seen:
            seen.add(t.id)
            mistakes.append(t)
    r.mistakes = mistakes
    r.mistakes_sum = stats.summary(journal, mistakes)
    return r


def extremes(journal, trades):
    """The two trades of the period worth opening again: the best and the
    worst, by R, since by money the largest account would win every month.
    One trade is never both: when every closed trade of the period carries
    the same R there is a best only."""
    closed = [t for t in trades if not t.is_open and journal.r(t.id) is not None]
    if not closed:
        return None, None
    best = max(closed, key=lambda t: journal.r(t.id))
    worst = min(closed, key=lambda t: journal.r(t.id))
    return best, (None if worst.id == best.id else worst)


def _r(journal, trade_id):
    """R for a table cell, a dash where it could not be measured."""
    r = journal.r(trade_id)
    return "-" if r is None else f"{r:+.2f}"


def balance_at(journal, account, moment):
    """The computed balance of an account on a date (everything strictly before)."""
    acc = journal.accounts.get(account)
    b = acc.start_balance if acc else 0.0
    b += sum(c.amount for c in journal.adjustments
             if c.account == account and c.day < moment)
    b += sum(t.pnl or 0.0 for t in journal.trades
             if t.account == account and not t.is_open and t.closed and t.closed < moment)
    return b


# --- the file -------------------------------------------------------------

def _money(x):
    return H.money(x, signed=True)


def _figures(s):
    return (f"{s.trades} | {f'{s.wr:.1f}%' if s.decided else '-'} | {s.sum_r:+.2f} | {s.average_r:+.2f} "
            f"| {_money(s.sum_pnl)}")


def to_markdown(r, journal, conclusions):
    """The report as the file keeps it: the same figures, as tables."""
    cur = H.sign(journal.currency())
    total, was = r.total, r.was

    def then(value, shown=True):
        return value if (was.trades and shown) else "-"

    lines = [f"# {r.name}", "", "## Summary", "",
             f"| metric | {r.name} | {r.earlier_name} |", "|---|---|---|",
             f"| trades | {total.trades} | {was.trades or '-'} |",
             f"| win / lose / BE | {total.wins} / {total.losses} / {total.be} "
             f"| {then(f'{was.wins} / {was.losses} / {was.be}')} |",
             f"| winrate (BE not counted) | {f'{total.wr:.1f}%' if total.decided else '-'} "
             f"| {then(f'{was.wr:.1f}%', was.decided)} |",
             f"| total R | {total.sum_r:+.2f} | {then(f'{was.sum_r:+.2f}')} |",
             f"| EV (average R, BE counted) | {total.average_r:+.2f} "
             f"| {then(f'{was.average_r:+.2f}')} |",
             f"| result in money | {_money(total.sum_pnl)} {cur} "
             f"| {then(f'{_money(was.sum_pnl)} {cur}')} |",
             f"| deepest fall from a high | {r.fall:+.2f} R "
             f"| {then(f'{r.was_fall:+.2f} R')} |",
             ""]
    if r.playbooks:
        lines += ["### By playbook", "",
                  f"| | trades | WR | Σ R | EV | Σ {cur} | clean | held |",
                  "|---|---|---|---|---|---|---|---|"]
        for pid, label, s, c, setups in r.playbooks:
            lines.append(f"| {label} | {_figures(s)} | {_clean(c)} | {_held(c)} |")
            for name, ss, cc in setups:
                lines.append(f"| · {name} | {_figures(ss)} | {_clean(cc)} | {_held(cc)} |")
        lines.append("")
    for heading, rows in r.slices:
        lines += [f"### {heading}", "",
                  f"| | trades | WR | Σ R | EV | Σ {cur} |", "|---|---|---|---|---|---|"]
        lines += [f"| {value} | {_figures(s)} |" for value, s in rows]
        lines.append("")
    lines += ["### Balance change by account", "",
              "| account | before | after | change |", "|---|---|---|---|"]
    for account, before, after in r.balances:
        # the change is the difference of the printed figures, or 1 000 -> 1 001
        # would read +2 for a real +1.2
        b0, b1 = round(before), round(after)
        lines.append(f"| {account} | {b0:,} | {b1:,} | {b1 - b0:+,} |"
                     .replace(",", " "))
    lines.append("")
    if r.best:
        lines += ["### Best and worst trade", "",
                  f"| trade | pair | style | R | {cur} |", "|---|---|---|---|---|"]
        for label, t in (("best", r.best), ("worst", r.worst)):
            if t:
                lines.append(f"| {t.id} | {t.pair} | {t.style} | {_r(journal, t.id)} "
                             f"| {_money(t.pnl or 0.0)} |")
        lines.append("")
    if r.ticked:
        lines += ["### Rules", "",
                  f"{r.ticked} {_plural(r.ticked, 'trade')} ticked against a playbook: "
                  f"{r.kept.trades} kept every rule, {r.broke.trades} broke one or more.", ""]
        if r.rules:
            lines += ["| rule not met | trades | Σ R | EV |", "|---|---|---|---|"]
            lines += [f"| {label} {rule.number}: {rule.text} | {n} | {s.sum_r:+.2f} "
                      f"| {s.average_r:+.2f} |" for label, rule, n, s in r.rules]
            lines.append("")
    if r.past_stop:
        lines += ["### Losses past the stop", "",
                  "| trade | pair | R | over |", "|---|---|---|---|"]
        lines += [f"| {t.id} | {t.pair} | {_r(journal, t.id)} "
                  f"| {stats.past_stop_over(journal, t):+.2f} |"
                  for t in r.past_stop]
        lines += ["", f"Over the stop as designed, -{journal.stop_edge:g} R: "
                      f"{r.past_stop_cost:+.2f} R.", ""]
    lines += ["### Process", ""]
    if not r.cards:
        lines += [f"No cards written for this period, and {r.days_traded} "
                  f"{_plural(r.days_traded, 'day')} had entries.", ""]
    else:
        lines += [f"{len(r.cards)} {_plural(len(r.cards), 'card')} written, {r.days_traded} "
                  f"{_plural(r.days_traded, 'day')} had entries.", "",
                  "| process grade | days |", "|---|---|"]
        lines += [f"| {grade} | {n} |" for grade, n in r.grades]
        lines.append("")
    if r.breakeven and r.breakeven.moved.trades:
        lines += [breakeven_words(r.breakeven), ""]
    # An empty section stays empty: whatever stands here is loaded into the
    # form as the owner's own text, so a hint would have to be deleted first.
    lines += ["", "## Conclusions", "", conclusions]
    return "\n".join(lines)


def breakeven_words(b):
    """The stops moved to the entry in one sentence, for the process part of
    a report, in plain words the page and the file both use."""
    m = b.moved
    ends = [f"{m.wins} won", f"{m.be} stopped at the entry"]
    if m.losses:
        ends.append(f"{m.losses} lost after it")
    words = (f"Stop moved to breakeven on {m.trades} of {m.trades + b.stayed.trades} "
             f"{_plural(m.trades + b.stayed.trades, 'trade')}: {', '.join(ends)}, "
             f"{m.sum_r:+.2f} R, EV {m.average_r:+.2f}")
    if b.stayed.trades:
        words += f"; the stop stayed on {b.stayed.trades}, EV {b.stayed.average_r:+.2f}"
    if b.median_hours is not None:
        words += f". Moved after {_hours(b.median_hours)} in the middle case"
        if b.median_share is not None:
            words += f", at {b.median_share * 100:.0f}% of the hold"
    return words + "."


def _hours(h):
    """A span in the unit a trader would say it in."""
    if h < 1:
        return f"{h * 60:.0f} min"
    if h < 48:
        return f"{h:.0f} h"
    return f"{h / 24:.1f} days"


def _clean(c):
    if c is None:
        return "-"
    share = "-" if c.clean_share is None else f"{c.clean_share:.0f}%"
    return share + (f" ({c.unticked} not ticked)" if c.unticked else "")


def _plural(n, word):
    return word if n == 1 else word + "s"


def _held(c):
    if c is None or c.held_share is None:
        return "-"
    return f"{c.held_share:.0f}%"


def build(root, journal, period, conclusions=None, problems=None):
    """Writes the file. Conclusions: the new ones, or the old ones kept."""
    r = compose(root, journal, period, problems)
    text = conclusions if conclusions is not None else previous_conclusions(root, period)
    head = {"period": period, "kind": r.kind,
            "updated": datetime.now().strftime("%Y-%m-%d %H:%M")}
    file = path(root, period)
    os.makedirs(os.path.dirname(file), exist_ok=True)
    tmp = file + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(mdfile.dump(head, to_markdown(r, journal, text)))
    os.replace(tmp, file)
    return file


def is_period(period):
    try:
        parse_period(period)
    except ValueError:
        return False
    return True


def existing(root):
    """The periods a report file stands for. A note or a copy left in the
    folder is passed over: the shelf composes every name it gets."""
    folder = os.path.join(root, store.JOURNAL, store.REPORTS)
    if not os.path.isdir(folder):
        return []
    names = [i[:-3] for i in os.listdir(folder)
             if i.endswith(".md") and is_period(i[:-3])]
    return sorted(names, reverse=True)


def read(root, period):
    """The header and the body of a report file, or (None, None) when there is
    none. A header edited by hand into something mdfile cannot read gives an
    empty header and the whole text as the body, so the page still opens."""
    file = path(root, period)
    if not os.path.exists(file):
        return None, None
    with open(file, encoding="utf-8") as f:
        text = f.read()
    try:
        return mdfile.parse(text)
    except ValueError:
        return {}, text


# --- the shelf --------------------------------------------------------------

def periods(journal, kind, now=None):
    """Every month (or quarter) from the first one a trade closed in up to the
    one running now, oldest first: the shelf the Reports tab lays them out on,
    a place for each whether a report stands there or not."""
    now = now or journal.now()
    closed = [t.closed for t in journal.trades if not t.is_open and t.closed]
    if not closed:
        return []
    first = period_of(min(closed), kind)
    last = period_of(now, kind)
    if first > last:
        first, last = last, first
    out, p = [], first
    while p <= last and len(out) < 600:
        out.append(p)
        p = next_period(p)
    return out
